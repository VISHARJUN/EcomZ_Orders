package com.ecomz.payments.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomz.dal.PaymentDAL;
import com.ecomz.payments.model.CreditCard;
import com.ecomz.payments.model.DebitCard;

@WebServlet("/paymentsController")
public class PaymentController extends HttpServlet {
	PrintWriter out = null;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		saveCreditCardDetails(request, response);
		updateCreditCardDetails(request, response);
		removeCreditCardDetails(request, response);
		saveDebitCardDetails(request,response);
		updateDebitCardDetails(request,response);
		removeDebitCardDetails(request,response);
		//saveCreditCardDetails(request,response);
		// code to connect to dp..and store the parameters....

		// trap all parameters in the model
		// send it to the repo
	}

	private void saveCreditCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("save".equals(request.getParameter("flag"))) {
				CreditCard creditcard = new CreditCard();
				creditcard.setCard_holders_name(request.getParameter("name"));
				creditcard.setCardNumber(Integer.parseInt(request.getParameter("cardNumber")));
		        creditcard.setCVV(Integer.parseInt(request.getParameter("cvv")));
				creditcard.setMonthOfExpiry((request.getParameter("expiry_month")));
				creditcard.setYearOfExpiry((request.getParameter("expiry_year")));
				System.out.println(
						"PaymentController:saveCreditDetails(HttpServletRequest request, HttpServletResponse response)"
								+ creditcard);

				out = response.getWriter();
				out.println("<html><body>");
				//out.println("(Credit Card details)");

				int rowsInserted = com.ecomz.dal.PaymentDAL.saveCreditCardDetails(creditcard);
				if (rowsInserted > 0) {
					out.println("CREDIT DETAILS ADDED SUCCESSFULLY");

				} else {
					out.println("FAILED ADDING CREDIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:CreditDetails(HttpServletRequest request, HttpServletResponse response) "
							+ e);

		}

	}
	
	private void updateCreditCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("update".equals(request.getParameter("flag"))) {
				CreditCard creditcard = new CreditCard();
				creditcard.setCard_holders_name(request.getParameter("name"));
				creditcard.setCardNumber(Integer.parseInt(request.getParameter("cardNumber")));
		        creditcard.setCVV(Integer.parseInt(request.getParameter("cvv")));
				creditcard.setMonthOfExpiry((request.getParameter("expiry_month")));
				creditcard.setYearOfExpiry((request.getParameter("expiry_year")));
				System.out.println(
						"PaymentController:updateCreditDetails(HttpServletRequest request, HttpServletResponse response)"
								+ creditcard);

				out = response.getWriter();
				out.println("<html><body>");
				//out.println("(Credit Card details)");

				int rowsInserted = PaymentDAL.updateCreditCardDetails(creditcard);
				if (rowsInserted > 0) {
					out.println("CREDIT DETAILS UPDATED SUCCESSFULLY");

				} else {
					out.println("FAILED UPDATING CREDIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:UpdateCreditDetails(HttpServletRequest request, HttpServletResponse response)"
							+ e);

		}

	}

	private void removeCreditCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("delete".equals(request.getParameter("flag"))) {
				CreditCard creditcard = new CreditCard();
				int rowToBeDeleted=(Integer.parseInt(request.getParameter("cardNumber")));
		
				System.out.println(
						"PaymentController:removeCreditDetails(HttpServletRequest request, HttpServletResponse response)"
								+ rowToBeDeleted);

				out = response.getWriter();
				out.println("<html><body>");
				//out.println("(Credit Card details)");

				int rowsInserted = PaymentDAL.removeCreditCardDetails(rowToBeDeleted);
				if (rowsInserted > 0) {
					out.println("CREDIT DETAILS DELETED SUCCESSFULLY");

				} else {
					out.println("FAILED DELETED CREDIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:removeCreditDetails(HttpServletRequest request, HttpServletResponse response)"
							+ e);


		}

	}
	
	private void saveDebitCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("saveDebit".equals(request.getParameter("flag"))) {
				DebitCard debitcard = new DebitCard();
				debitcard.setCard_holders_name(request.getParameter("name"));
				debitcard.setCardNumber(Integer.parseInt(request.getParameter("cardNumber")));
				debitcard.setCvv(Integer.parseInt(request.getParameter("cvv")));
				debitcard.setMonthOfExpiry((request.getParameter("expiry_month")));
				debitcard.setYearOfExpiry((request.getParameter("expiry_year")));
				System.out.println(
						"PaymentController:saveDebitDetails(HttpServletRequest request, HttpServletResponse response)"
								+ debitcard);

				out = response.getWriter();
				out.println("<html><body>");

				int rowsInserted = PaymentDAL.saveDebitCardDetails(debitcard);
				if (rowsInserted > 0) {
					out.println("DEBIT DETAILS ADDED SUCCESSFULLY");

				} else {
					out.println("FAILED ADDING DEBIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:saveDebitDetails(HttpServletRequest request, HttpServletResponse response) "
							+ e);

		}

	}
	
	private void updateDebitCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("updateDebit".equals(request.getParameter("flag"))) {
				DebitCard debitcard = new DebitCard();
				debitcard.setCard_holders_name(request.getParameter("name"));
				debitcard.setCardNumber(Integer.parseInt(request.getParameter("cardNumber")));
				debitcard.setCvv(Integer.parseInt(request.getParameter("cvv")));
				debitcard.setMonthOfExpiry((request.getParameter("expiry_month")));
				debitcard.setYearOfExpiry((request.getParameter("expiry_year")));
				System.out.println(
						"PaymentController:saveDebitDetails(HttpServletRequest request, HttpServletResponse response)"
								+ debitcard);

				out = response.getWriter();
				out.println("<html><body>");

				int rowsInserted = PaymentDAL.updateDebitCardDetails(debitcard);
				if (rowsInserted > 0) {
					out.println("DEBIT DETAILS ADDED SUCCESSFULLY");

				} else {
					out.println("FAILED ADDING DEBIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:saveDebitDetails(HttpServletRequest request, HttpServletResponse response) "
							+ e);

		}

	}
	
	private void removeDebitCardDetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("deleteDebit".equals(request.getParameter("flag"))) {
				CreditCard creditcard = new CreditCard();
				int rowToBeDeleted=(Integer.parseInt(request.getParameter("cardNumber")));
		
				System.out.println(
						"PaymentController:removeDebitDetails(HttpServletRequest request, HttpServletResponse response)"
								+ rowToBeDeleted);

				out = response.getWriter();
				out.println("<html><body>");
				//out.println("(Credit Card details)");

				int rowsInserted = PaymentDAL.removeDebitCardDetails(rowToBeDeleted);
				if (rowsInserted > 0) {
					out.println("DEBIT DETAILS DELETED SUCCESSFULLY");

				} else {
					out.println("FAILED DELETED DEBIT DETAILS");
				}
				out.println("</body></html>");

			}
		} catch (Exception e) {
			System.err.println(
					"PaymentController:removeDebitDetails(HttpServletRequest request, HttpServletResponse response)"
							+ e);


		}

	}
}
