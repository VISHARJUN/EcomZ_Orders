package com.ecomz.payments;

public class PaymentsModule {
	public PaymentsModule() {

	}
}
