package com.ecomz.payments.model;

public class CreditCard implements Payments {
	

		private String card_holders_name;
		private int cardNumber;
		private int CVV;
		private String monthOfExpiry;
		private String yearOfExpiry;
		public String cardType="creditCard";
		public CreditCard(){}
		
		public CreditCard(String card_holders_name, int cardNumber, int cVV, String monthOfExpiry, String yearOfExpiry) {
			super();
			this.card_holders_name = card_holders_name;
			this.cardNumber = cardNumber;
			CVV = cVV;
			this.monthOfExpiry = monthOfExpiry;
			this.yearOfExpiry = yearOfExpiry;
		}

		public String getCard_holders_name() {
			return card_holders_name;
		}

		public void setCard_holders_name(String card_holders_name) {
			this.card_holders_name = card_holders_name;
		}

		public int getCardNumber() {
			return cardNumber;
		}

		public void setCardNumber(int cardNumber) {
			this.cardNumber = cardNumber;
		}

		public int getCVV() {
			return CVV;
		}

		public void setCVV(int cVV) {
			CVV = cVV;
		}

		public String getMonthOfExpiry() {
			return monthOfExpiry;
		}

		public void setMonthOfExpiry(String monthOfExpiry) {
			this.monthOfExpiry = monthOfExpiry;
		}

		public String getYearOfExpiry() {
			return yearOfExpiry;
		}

		public void setYearOfExpiry(String yearOfExpiry) {
			this.yearOfExpiry = yearOfExpiry;
		}

		@Override
		public void pay(int amount){
			System.out.println(amount + "paid with credit card");
		}
	}
		
		

