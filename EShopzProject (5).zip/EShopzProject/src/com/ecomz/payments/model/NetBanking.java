package com.ecomz.payments.model;

public class NetBanking implements Payments {

		
		private String bankName;
		private String accountNumber;
		private String IFSC_Code;
		
		public NetBanking(String bankName,String accountNumber,String IFSC_Code)
		{
			this.bankName=bankName;
			this.accountNumber=accountNumber;
			this.IFSC_Code=IFSC_Code;
		}
		@Override
		public void pay(int amount) {
			System.out.println(amount +" paid through netbanking");
		}

	}

