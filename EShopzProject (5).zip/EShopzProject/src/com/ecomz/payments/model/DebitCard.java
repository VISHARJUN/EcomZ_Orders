package com.ecomz.payments.model;

public class DebitCard implements Payments{

		private String card_holders_name;;
		private int cardNumber;
		private int cvv;
		private String monthOfExpiry;
		private String yearOfExpiry;
		public String cardType="debitCard";
		
		public DebitCard(){}
		
		public DebitCard(String card_holders_name, int cardNumber, int cvv,  String monthOfExpiry, String yearOfExpiry){
			super();
			this.card_holders_name=card_holders_name;
			this.cardNumber=cardNumber;
			this.cvv=cvv;
			this.monthOfExpiry = monthOfExpiry;
			this.yearOfExpiry = yearOfExpiry;
		}
		public String getCard_holders_name() {
			return card_holders_name;
		}
		public void setCard_holders_name(String card_holders_name) {
			this.card_holders_name = card_holders_name;
		}
		public int getCardNumber() {
			return cardNumber;
		}
		public void setCardNumber(int cardNumber) {
			this.cardNumber = cardNumber;
		}
		public int getCvv() {
			return cvv;
		}
		public void setCvv(int cvv) {
			this.cvv = cvv;
		}
		public String getMonthOfExpiry() {
			return monthOfExpiry;
		}
		public void setMonthOfExpiry(String monthOfExpiry) {
			this.monthOfExpiry = monthOfExpiry;
		}
		public String getYearOfExpiry() {
			return yearOfExpiry;
		}
		public void setYearOfExpiry(String yearOfExpiry) {
			this.yearOfExpiry = yearOfExpiry;
		}
		@Override
		public void pay(int amount) {
			System.out.println(amount +" paid with debit card");
		}

	}


