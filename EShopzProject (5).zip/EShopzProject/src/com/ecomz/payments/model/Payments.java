package com.ecomz.payments.model;

public interface Payments {

			public void pay(int amount);                             
			
		}


