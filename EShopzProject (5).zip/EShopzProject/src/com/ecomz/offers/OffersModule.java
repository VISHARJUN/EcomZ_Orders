package com.ecomz.offers;

public class OffersModule {
public OffersModule() {
	// TODO Auto-generated constructor stub
}
}
