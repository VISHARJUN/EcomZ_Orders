package com.ecomz.products;

public class ProductsModule {
public ProductsModule() {
	System.out.println("Products Module!");
}
}
