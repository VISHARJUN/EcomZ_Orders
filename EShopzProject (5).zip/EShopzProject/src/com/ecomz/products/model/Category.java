package com.ecomz.products.model;

public class Category {
	String categoryId;
	String categoryName;
	
	
	public Category(String categoryName, String categoryId) {
		super();
		this.categoryName = categoryName;
		this.categoryId = categoryId;
	}

	@Override
	public String toString() {
		return "Category [categoryName=" + categoryName + ", categoryId=" + categoryId + "]";
	}

	
}
