package com.ecomz.products.model;

public class Product {
	String productId;
	String categoryId;
	String productName;
	float price;
	String inStock;
	String seller;
	String description;
	String imageUrl;
		
	
	public Product() {
	}


	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public String getInStock() {
		return inStock;
	}


	public void setInStock(String inStock) {
		this.inStock = inStock;
	}


	public String getSeller() {
		return seller;
	}


	public void setSeller(String seller) {
		this.seller = seller;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getImageUrl() {
		return imageUrl;
	}


	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", categoryId=" + categoryId + ", productName=" + productName
				+ ", price=" + price + ", inStock=" + inStock + ", seller=" + seller + ", description=" + description
				+ ", imageUrl=" + imageUrl + "]";
	}
	
	

}
