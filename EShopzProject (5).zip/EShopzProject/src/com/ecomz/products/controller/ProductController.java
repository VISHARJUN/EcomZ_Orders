package com.ecomz.products.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecomz.dal.ProductDAL;
import com.ecomz.products.model.Product;;

@WebServlet("/productController")

public class ProductController extends HttpServlet {
	PrintWriter out = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		createProduct(request, response);
		modifyProduct(request, response);
		removeProduct(request, response);
		addToCart(request,response);
	}

	private void createProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("createProduct".equals(request.getParameter("flag"))) {
				Product product = new Product();
				product.setProductId(request.getParameter("productId"));
				product.setCategoryId(request.getParameter("categoryId"));
				product.setProductName(request.getParameter("productName"));
				product.setPrice(Integer.parseInt(request.getParameter("price")));
				product.setInStock(request.getParameter("inStock"));
				product.setSeller(request.getParameter("seller"));
				product.setDescription(request.getParameter("description"));
				product.setImageUrl(request.getParameter("url"));

				System.out.println(
						"ProductController:createProduct(HttpServletRequest request, HttpServletResponse response):"
								+ product);

				out = response.getWriter();
				out.println("<html><body>");
				out.println("<a href='/views/product/createProduct.html'>(Add a product)</a>");
				// out.println("<a href='viewPlants.jsp'>(View plant)</a>");
				int rowsInserted = ProductDAL.createProduct(product);
				if (rowsInserted > 0) {
					out.println("Product created succesfully!");

				} else {
					out.println("Failed creating product! ");
				}
				out.println("</body></html>");
			}
		} catch (Exception exception) {
			System.err.println("ProductController:createProduct(HttpServletRequest request, HttpServletResponse response):"
					+ exception);
		}
	}

	private void modifyProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {

		try {
			if ("modifyProduct".equals(request.getParameter("flag"))) {
				Product product = new Product();
				product.setProductId(request.getParameter("productId"));
				product.setCategoryId(request.getParameter("categoryId"));
				product.setProductName(request.getParameter("productName"));
				product.setPrice(Integer.parseInt(request.getParameter("price")));
				product.setInStock(request.getParameter("inStock"));
				product.setSeller(request.getParameter("seller"));
				product.setDescription(request.getParameter("description"));
				product.setImageUrl(request.getParameter("url"));

				System.out.println(
						"ProductController:createProduct(HttpServletRequest request, HttpServletResponse response):"
								+ product);

				out = response.getWriter();
				out.println("<html><body>");
				out.println("<a href='/views/product/modifyProduct.html'>(Update a Product )</a>");
				// out.println("<a href='viewPlants.jsp'>(View plant)</a>");
				int rowsUpdated = ProductDAL.modifyProduct(product);
				if (rowsUpdated > 0) {
					out.println("Product modified succesfully!");

				} else {
					out.println("Failed modifying  product! ");
				}
				out.println("</body></html>");
			}
		} catch (Exception exception) {
			System.err.println("ProductController:createProduct(HttpServletRequest request, HttpServletResponse response):"
					+ exception);
		}
	}

	private void removeProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("removeProduct".equals(request.getParameter("flag"))) {
				String rowToBeDeleted = request.getParameter("productId");

				System.out.println(
						"ProductController:removeProduct(HttpServletRequest request, HttpServletResponse response):"
								+ rowToBeDeleted);

				out = response.getWriter();
				out.println("<html><body>");
				out.println("<a href='../../views/product/removeProduct.html'>(Delete a product)</a>");

				int rowsInserted = ProductDAL.removeProduct(rowToBeDeleted);
				if (rowsInserted > 0) {
					out.println("Product removed succesfully!");

				} else {
					out.println("Failed removing product! ");
				}
				out.println("</body></html>");
			}
		} catch (Exception exception) {
			System.err.println(
					"ProductController:removeProduct(HttpServletRequest request, HttpServletResponse response):"
							+ exception);
		}

	}

	private void addToCart(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			if ("addToCart".equals(request.getParameter("flag"))) {
				String productId = request.getParameter("productId");

				System.out.println(
						"ProductController:addToCart(HttpServletRequest request, HttpServletResponse response):"
								+ productId);
			HttpSession httpSession = request.getSession();
			ArrayList<Product> cart = (ArrayList)httpSession.getAttribute("cart");
			Product product = new Product();
			product.setProductId(productId);
			cart.add(product);
			System.out.println("ProductController:addToCart(HttpServletRequest request, HttpServletResponse response): "+ cart);
			httpSession.setAttribute("cart",cart);
			response.sendRedirect("views/products/products.jsp");
			}
		} catch (Exception exception) {
			System.err.println(
					"ProductController:addToCart(HttpServletRequest request, HttpServletResponse response):"
							+ exception);
		}

	}


}
