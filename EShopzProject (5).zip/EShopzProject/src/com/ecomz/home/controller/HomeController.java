package com.ecomz.home.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecomz.dal.HomeDAL;
import com.ecomz.home.model.Customer;
import com.ecomz.home.model.Login;
import com.ecomz.products.model.Product;



@WebServlet("/homeController")
public class HomeController extends HttpServlet {

	PrintWriter out=null;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		customerRegistration(request,response);
		customerLogin(request,response);
		customerLogout(request,response);
	}

	private void customerRegistration(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try{
			if("register".equals(request.getParameter("flag"))){
				Customer customer = new Customer();
				customer.seteMailId(request.getParameter("email_id"));
				customer.setFirstName(request.getParameter("f_name"));
				customer.setLastName(request.getParameter("l_name"));
				customer.setContactNumber(request.getParameter("contact_number"));
				customer.setAddress(request.getParameter("address"));
				customer.setPassword(request.getParameter("password"));
				System.out.println(customer);
				out = response.getWriter();
				out.println("<html><body>");
				int rowsInserted=HomeDAL.registerCustomer(customer);
				if(rowsInserted>0){
					response.sendRedirect("views/home/jsp/home.jsp");							
				}
				else
				{
					out.println("FAILED REGISTRATION!");
				}
				out.println("</body></html>");
			}
		}catch(Exception exception){
			System.err.println("HomeController:customerRegistration(HttpServletRequest request,HttpServletResponse response):"+exception);;
		}
	}

	private void customerLogin(HttpServletRequest request,HttpServletResponse response){
		try{
			if("login".equals(request.getParameter("flag"))){
				Login login = new Login();

				login.seteMailId(request.getParameter("email_id"));
				login.setPassword(request.getParameter("password"));

				System.out.println(login);
				out = response.getWriter();
				out.println("<html><body>");
				String loggedUser=HomeDAL.loginCustomer(login);
				if(!(loggedUser.equals(null))){
					out.println(loggedUser+" LOGGED IN SUCCESSFULLY!");	
					HttpSession session = request.getSession();
					session.setAttribute("firstName", loggedUser);
					ArrayList<Product> cart = new ArrayList<Product>();
					session.setAttribute("cart", cart);
					/*RequestDispatcher requestDispatcher = request.getRequestDispatcher("views/home/jsp/home.jsp");
					requestDispatcher.forward(request,response);*/
					response.sendRedirect("views/home/jsp/home.jsp");
				}
				else
				{
					out.println("FAILED LOGIN!");
				}
				out.println("</body></html>");
			}
		}catch(Exception exception){
			System.err.println("HomeController:customerLogin(HttpServletRequest request,HttpServletResponse response):"+exception);;
		}
	}

	private void customerLogout(HttpServletRequest request,HttpServletResponse response){
		try{
			if("logout".equals(request.getParameter("flag"))){

				HttpSession session = request.getSession();
				session.invalidate();
				System.out.println("Succesfully logged out");
				response.sendRedirect("views/home/jsp/home.jsp");
			
			}
		}catch(Exception exception){
			System.err.println("HomeController:customerLogout(HttpServletRequest request,HttpServletResponse response):"+exception);;
		}
	}
}
