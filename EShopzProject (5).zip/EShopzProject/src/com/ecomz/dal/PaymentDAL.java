package com.ecomz.dal;
import com.ecomz.payments.model.CreditCard;
import com.ecomz.payments.model.DebitCard;

public class PaymentDAL {
	public static int saveCreditCardDetails(CreditCard creditcard) {
		try {
			String insertQuery ="insert into Card values('" + creditcard.getCard_holders_name() + "','" + creditcard.getCardNumber() + "','" + creditcard.cardType + "','" +creditcard.getCVV() + "','"+ creditcard.getMonthOfExpiry()+"','"+ creditcard.getYearOfExpiry()+"')";
			MasterDAL.insertRow(insertQuery);
			return 1;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:saveCreditDetails(CreditCard creditcard):" + exception);
			return 0;
		}


	}
	public static int updateCreditCardDetails(CreditCard creditcard) {
		try {
			String updateQuery ="update card set card_holders_name='" + creditcard.getCard_holders_name() + "',cvv='" + creditcard.getCVV() + "',card_expiry_month='"+ creditcard.getMonthOfExpiry()+"',card_expiry_year='"+ creditcard.getYearOfExpiry()+"' where card_number='" + creditcard.getCardNumber() + "'";
			int rowsaffected=MasterDAL.updateRow(updateQuery);
			return rowsaffected;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:updateCreditDetails(CreditCard creditcard):" + exception);
			return 0;
		}
	}

	public static int removeCreditCardDetails(int rowToBeDeleted) {
		try {
			String deleteQuery = "delete from card where card_number='"+rowToBeDeleted+"'";
			int recordsaffected=MasterDAL.deleteRow(deleteQuery);
			return recordsaffected;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:removeCreditCardDetails(int rowToBeDeleted):" + exception);
			return 0;
		}
	}

	
	public static int saveDebitCardDetails(DebitCard debitcard) {
		try {
			String insertQuery ="insert into Card values('" + debitcard.getCard_holders_name() + "','" + debitcard.getCardNumber() + "','" + debitcard.cardType + "','" +debitcard.getCvv() + "','"+ debitcard.getMonthOfExpiry()+"','"+ debitcard.getYearOfExpiry()+"')";
			MasterDAL.insertRow(insertQuery);
			return 1;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:saveDebitCardDetails(DebitCard debitcard):" + exception);
			return 0;
		}
}
	
	public static int updateDebitCardDetails(DebitCard debitcard) {
		try {
			String updateQuery ="update card set card_holders_name='" + debitcard.getCard_holders_name() + "',cvv='" + debitcard.getCvv() + "',card_expiry_month='"+ debitcard.getMonthOfExpiry()+"',card_expiry_year='"+ debitcard.getYearOfExpiry()+"' where card_number='" + debitcard.getCardNumber() + "'";
			MasterDAL.updateRow(updateQuery);
			return 1;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:udpateDebitCardDetails(DebitCard debitcard):" + exception);
			return 0;
		}
}
	
	public static int removeDebitCardDetails(int rowToBeDeleted) {
		try {
			String deleteQuery ="delete from card where card_number='"+rowToBeDeleted+"'";
			MasterDAL.deleteRow(deleteQuery);
			return 1;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("PaymentDAL:deleteDebitCardDetails(DebitCard debitcard):" + exception);
			return 0;
		}
}
}