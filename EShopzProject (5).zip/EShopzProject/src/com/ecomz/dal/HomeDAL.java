package com.ecomz.dal;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.ecomz.home.model.Customer;
import com.ecomz.home.model.Login;

public class HomeDAL {

	static PrintWriter out=null;
	public static Connection getConnection(){
		Connection connection = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		} catch(Exception e){
			System.out.println(e);
		}
		return connection;
	}

	public static int registerCustomer(Customer customer){
		int recordsAffected=0;
		try{
			String insertCustomer="insert into customer values ('"+customer.geteMailId()+"','"+customer.getFirstName()+"','"+customer.getLastName()+"','"+customer.getContactNumber()+"','"+customer.getAddress()+"','"+customer.getPassword()+"')";
			
			recordsAffected=MasterDAL.insertRow(insertCustomer);
			System.out.println("DAO : User registered!");
		} catch(Exception exception){
			System.err.println("HomeDAL:registerCustomer(Customer customer): " + exception);
		}
		return recordsAffected;
	}

	public static String loginCustomer(Login login){
		try{
			
			String loginCustomer = "SELECT password,first_name FROM customer where email_id= '"+login.geteMailId()+"'";
		
			ResultSet resultSet = MasterDAL.selectRows(loginCustomer)
;			if(resultSet.next()){
				if((login.getPassword().equals(resultSet.getString("password")))){
					System.out.println("Logged in successfully");
					return resultSet.getString("first_name");
				}
				else{
					System.out.println("Unsuccessful login");
					return null;
				}
			}
			return null;
		} catch(Exception exception){
			System.err.println("HomeDAL:loginCustomer(Login login): " + exception);
			return null;
		}


	}
}
