package com.ecomz.dal;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.ecomz.module.model.Model;

public class ModuleDAL {
	public static Model getModel(String modelId) {
		try {
			ResultSet modelResultSet = null;
			Model model = null;
			String selectQuery = "select * from dummy where model_id = '" + modelId+ "'";
			modelResultSet = MasterDAL.selectRows(selectQuery);
			while(modelResultSet.next()){
				model.setModelId(modelResultSet.getString("model_id"));
				model.setModelId(modelResultSet.getString("model_name"));
			}
			return model;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ModuleDAL:getModel(String model_id):" + exception);
		}
		return null;
	}
	public static ArrayList getModels() {
		try {
			ResultSet modelResultSet = null;
			ArrayList<Model> models = null;
			String selectQuery = "select * from dummy";
			modelResultSet = MasterDAL.selectRows(selectQuery);
			while(modelResultSet.next()){
				Model model = null;
				model.setModelId(modelResultSet.getString("model_id"));
				model.setModelId(modelResultSet.getString("model_name"));
				models.add(model);
			}
			return models;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ModuleDAL:getModels():" + exception);
		}
		return null;
	}
	public static void createModel(Model model) {
		try {
			String insertQuery = "insert into dummy('" + model.getModelId() + "','" + model.getModelName() + "'";
			MasterDAL.insertRow(insertQuery);
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ModuleDAL:createModel(Model model):" + exception);
		}
	}
	public static void modifyModel(Model model) {
		try {
			String updateQuery = "constructed update query";
			MasterDAL.updateRow(updateQuery);
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ModuleDAL:modifyModel(Model model):" + exception);
		}
	}
	public static void removeModel(Model model) {
		try {
			String deleteQuery = "constructed delete query";
			MasterDAL.deleteRow(deleteQuery);
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ModuleDAL:removeModel:" + exception);
		}
	}
}
