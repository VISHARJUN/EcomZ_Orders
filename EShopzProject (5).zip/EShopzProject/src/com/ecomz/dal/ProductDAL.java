package com.ecomz.dal;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.ecomz.module.model.Model;
import com.ecomz.products.model.Product;;

public class ProductDAL {
	public static Product getProduct(String productId) {
		try {
			ResultSet productResultSet = null;
			Product product = null;
			String selectQuery = "select * from products where product_id = '" + productId+ "'";
			productResultSet = MasterDAL.selectRows(selectQuery);
			while(productResultSet.next()){
				product.setProductId(productResultSet.getString("product_id"));
				product.setCategoryId(productResultSet.getString("categoryId"));
				product.setProductName(productResultSet.getString("productName"));
				product.setPrice(productResultSet.getFloat("price"));
				product.setInStock(productResultSet.getString("inStock"));
				product.setSeller(productResultSet.getString("seller"));
				product.setDescription(productResultSet.getString("description"));
				product.setImageUrl(productResultSet.getString("url"));
				
			}
			return product;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ProductDAL:getProduct(String product_id):" + exception);
		}
		return null;
	}
	public static ArrayList getProducts() {
		try {
			ResultSet productResultSet =null;
			ArrayList<Product> products = new ArrayList<Product>();
			String selectQuery = "select * from products";
			productResultSet = MasterDAL.selectRows(selectQuery);
			while(productResultSet.next()){
			
				Product product = new Product();
				product.setProductId(productResultSet.getString("product_id"));
				product.setCategoryId(productResultSet.getString("category_id"));
				product.setProductName(productResultSet.getString("product_name"));
				product.setPrice(productResultSet.getFloat("price"));
				product.setInStock(productResultSet.getString("in_stock"));
				product.setSeller(productResultSet.getString("seller"));
			    product.setDescription(productResultSet.getString("description"));
				product.setImageUrl(productResultSet.getString("image_url"));
				
				products.add(product);
			}
			return products;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ProductDAL:getProducts():" + exception);
		}
		return null;
	}
	public static int createProduct(Product product) {
		int recordsAffected = 0;
		try {

			// Connection connection=MasterDAL.getConnectionToDatabase(true);
			String insertQuery = "insert into products values('" + product.getProductId() + "','"
					+ product.getCategoryId() + "','" + product.getProductName() + "','" + product.getPrice() + "','"
					+ product.getInStock() + "','" + product.getSeller() + "','" + product.getDescription() + "','"
					+ product.getImageUrl() + "')";
			recordsAffected = MasterDAL.insertRow(insertQuery);
			System.out.println("ProductDAL:createProduct(Product product):Product saved!");

		} catch (Exception sqlException) {
			System.err.println("ProductDAl:createProduct(Product product): " + sqlException);
		}
		return recordsAffected;
	}

	public static int modifyProduct(Product product) {
		int recordsAffected=0;
		try {
			String updateQuery = "update products set product_name='"+product.getProductName()+"' ,price='"+product.getPrice()+"',in_stock='"+product.getInStock()+"',seller='"+product.getSeller()+"',description='"+product.getDescription()+"',image_url='"+product.getImageUrl()+"' where product_id='"+product.getProductId()+"'";
					
			recordsAffected=MasterDAL.updateRow(updateQuery);
			System.out.println("ProductDAL:updateProduct(Product product):Product updated!");
		} catch (Exception exception) {
			System.err.println("ProductDAL:modifyProduct(Product product):" + exception);
		}
return recordsAffected;
	}
	public static int removeProduct(String rowToBeDeleted) {
		try {
			
			String deleteQuery = "delete from products where product_id='"+rowToBeDeleted+"'";
			int recordsAffected = MasterDAL.deleteRow(deleteQuery);
			return recordsAffected;
			//Use if to have your own message.
		} catch (Exception exception) {
			System.err.println("ProductDAL:removeProduct:" + exception);
		}
		return 0;
	}
}