package com.ecomz.orders;

public class OrdersModule {
public OrdersModule() {
	// TODO Auto-generated constructor stub
}
}
