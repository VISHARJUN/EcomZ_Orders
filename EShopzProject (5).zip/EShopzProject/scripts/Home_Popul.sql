insert into customer values('varun@abc.com','varun','kumar','9035467622','bangalore','varunkumar');
insert into customer values('surya@abc.com','surya','nidhi','9742304769','bangalore','suryanidhi');
insert into customer values('soumya@abc.com','soumya','majumder','9087654321','kolkata','soumyam');
COMMIT;